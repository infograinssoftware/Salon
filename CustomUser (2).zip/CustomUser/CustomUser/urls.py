from django.contrib import admin
from . import  settings
from django.contrib.staticfiles.urls import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import path, include
from core.views import CancelView, SuccessView, CreateCheckoutSessionView, ProductLandingPageView
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('authentication.urls')),
    path('core/',include('core.urls')),
    path('super/',include('superadmin.urls')),
    path('api/',include('core.api.urls')),
    path('api/',include('authentication.api.urls')),
    path('api/',include('superadmin.api.urls')),
    path('accounts/', include('allauth.urls')), 

    #For Stripe urls
    path('cancel/', CancelView.as_view(), name='cancel'),
    path('success/', SuccessView.as_view(), name='success'),
    path('product_landing/',ProductLandingPageView.as_view(), name='product_landing'),
    path('product_landing/<int:id>',ProductLandingPageView.as_view(), name='product_landing'),
    path('create-checkout-session/<pk>', CreateCheckoutSessionView.as_view(), name='create-checkout-session')
]
urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)