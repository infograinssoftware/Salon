from django.shortcuts import render, redirect 
from django.http import HttpResponse
from authentication.models import User_Registration, User_OTP, User_TemperoryModel, Vendor_Registration, Vendor_OTP, Vendor_TemperoryModel
from django.contrib.auth import authenticate, login, logout
from users.models import User
from rest_framework.authtoken.models import Token
import http.client
from django.contrib.auth.tokens import default_token_generator
import random
from django.conf import settings
from django.shortcuts import get_object_or_404
from django.views.generic import View
from django.contrib.auth.decorators import login_required
from superadmin.models import Service, ServiceClass
from core.models import VendorService
# from superadmin.forms import VendorServiceForm
# from core.forms import VendorServiceDetailForm
def send_otp(mobile, otp):
    conn = http.client.HTTPSConnection("api.msg91.com")
    authkey = settings.AUTH_KEY 
    headers = { 'content-type': "application/json" }
    space=" "
    url = f'http://control.msg91.com/api/sendotp.php?otp={otp}&message=Please_verify_your_otp_{otp}&mobile={mobile}&authkey={authkey}&country=91'
    conn.request("GET", url , headers=headers)
    res = conn.getresponse()
    data = res.read()
    print(data)
    return None

def location(request):
    return render(request,'user/location.html')
def register(request):
    request.session['type'] ='user'
    if request.method=='POST':
        email = request.POST.get('email','')
        phone = request.POST.get('phone','')
        password = request.POST.get('password','')
        confirm_password = request.POST.get('confirm_password','')
        first_name = request.POST.get('first_name','')
        last_name = request.POST.get('last_name','')
        address = request.POST.get('address','')
        city = request.POST.get('city','')
        state = request.POST.get('state','')
        zipcode = request.POST.get('zipcode','')
        country = request.POST.get('country','')
        latitude = request.POST.get('latitude', 0.0)
        longitude = request.POST.get('longitude',0.0)
        print(latitude, longitude)
        referralCode = request.POST.get('referralCode','')
        print('Bhiya ram')
        user_exs = User.objects.filter(phone = phone, is_active = True).exists()
        if user_exs:
            print('helllo user')
            print(user_exs)
            return render(request,'user/index.html',{'msg':'Phone number already taken'})
        user_exs = User.objects.filter(email = email, is_active = True).exists()
        print(user_exs)
        if user_exs:
            print('helllo user')
            print(user_exs)
            return render(request,'user/index.html',{'msg':'Email already taken'})
        if password == confirm_password:
            try:
                print('48')
                user = User.objects.create_user(email = email, phone = phone, password= password, first_name = first_name, last_name = last_name, is_active = False)
                print(user)
                print('50')
                x = User_TemperoryModel.objects.create(user = user, address= address, city = city, state = state, zipcode = zipcode, country = country, latitude = latitude, longitude = longitude)
                print('jitendra')
                x.save()
                print('meena')
                otp_gen= str(random.randint(1000,9999))
                otp_obj = User_OTP(user = x, phone = phone, otp_num = otp_gen)
                otp_obj.save()
                if otp_obj is not None:
                    request.session['mobile'] = phone
                    send_otp(phone, otp_gen)
                    return redirect('/otp/')
            except Exception as e:
                print(e)
                print('65')
                print(phone)
                try:
                    user_obj = User.objects.filter(phone = phone)
                    print('phone verified')
                except Exception as e:
                    print(e)
                    user_obj = User.objects.filter(email = email)
                    print('hello user')
                print('68')
                user_obj.delete()
                user = User.objects.create_user(email = email, phone = phone, password = password, first_name = first_name, last_name = last_name, is_active = False)
                print(user)
                x = User_TemperoryModel.objects.create(user = user, address= address, city = city, state = state, zipcode = zipcode, country = country, latitude = latitude, longitude = longitude)
                print('jitendra')
                x.save()
                print('meena')
                otp_gen = str(random.randint(1000,9999))
                otp_obj = User_OTP(user = x, phone = phone, otp_num = otp_gen)
                otp_obj.save()
                if otp_obj is not None:
                    request.session['mobile'] = phone
                    send_otp(phone, otp_gen)
                    return redirect('/otp/')
                # return render(request,'user/index.html',{'msg':'Re-Enter your details'})
        else:
            return render(request,'user/index.html',{'error':'password not matched'})
    else:
        if request.user.is_authenticated:
            return render(request,'home.html')
        return render(request,'user/index.html')

def edit_Profile(request):
    if request.method == 'GET':
        if request.user.is_authenticated:
            print(request.user)
            user_profile = User_Registration.objects.filter(user = request.user)
            
            # user_profile = User_Registration.objects.all()
            # for i in user_profile:
            #     print(i.address,i.user.first_name)
            #     print()
            # user_profile = User.objects.filter(email = request.user)
            # print(user_profile.profile_pic)
            # print(user_profile,'114')
            return render(request, 'user/edit_profile.html', {'user_data' : user_profile })
        else:
            return render(request, 'user/login.html')
    elif request.method == 'POST':
        img = request.FILES.get('profile_change')
        print(img)
        if img!= None:
            print("hii")
            profile_pic = request.FILES['profile_change']
            user_obj = get_object_or_404(User_Registration, user = request.user)
            user_obj.profile_pic = profile_pic
            user_obj.save()
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        phone = request.POST['phone']
        print(phone)
        user_obj = get_object_or_404(User, email = request.user)
        user_obj.first_name = first_name
        print(user_obj.first_name)
        user_obj.last_name = last_name
        user_obj.phone = phone
        print(user_obj.phone)
        user_obj.save()
        address = request.POST['address']
        user_obj = get_object_or_404(User_Registration, user = request.user)
        user_obj.address = address
        user_obj.save()
        print(request.FILES)
        return redirect('/edit_userprofile')
        
def loginnow(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try :
            echeck = get_object_or_404(Vendor_Registration, vuser__email = email)
            print(echeck)
            print('Jai ambey mata')
            return render(request,'user/login.html', {'msg' : 'Already Registered for Vendor'})
        except Exception as e:
            print('Jai bhawani')
            print(e)
        user = authenticate(request, email = email, password = password)
        print(user)
        if user is not None:
            login(request, user)
            token, created = Token.objects.get_or_create(user=user)
            return render(request,'home.html')
        else:
            return render(request,'user/login.html')
    else:
        if request.user.is_authenticated:
            return render(request, 'home.html')
        return render(request,'user/login.html')

def user_social_login(request):
    if request.session.get('type') == 'user':
        user = User.objects.get(email = request.user)
        print(user)
        user_reg = User_Registration.objects.get_or_create(user = user)
        user_temp = User_TemperoryModel.objects.get_or_create(user = user)
        print(user_reg, user_temp)
        return redirect('/user_phone_verify')
    elif request.session.get('type') == 'vendor':
        if User_Registration.objects.filter(user = request.user).exists() or User_TemperoryModel.objects.filter(user = request.user).exists():
            request.session['type'] = 'user'
            return redirect('/user_social_login')
        user = User.objects.get(email = request.user)
        print(user)
        user_reg = Vendor_Registration.objects.get_or_create(vuser = user)
        print(user_reg)
        return redirect('/edit_vendorprofile')


def otp_verify(request):
    if request.method == 'POST':
        phone = request.session['mobile']
        print(phone,'200')
        user_otp = request.POST.get('otp')
        try:
            otp_obj = get_object_or_404(User_OTP, phone=phone)
            print(otp_obj)
        except Exception as e:
            print(e)
            return render(request,'user/otp.html',{'msg':'Incorrect OTP'})
        db_otp = otp_obj.otp_num
        if db_otp == user_otp:
            print(otp_obj.user.id)
            
            #Fetching data from temperory table and then putting it into the Registration table
            # 1.Temp Table
            try:
                temp_obj = get_object_or_404(User_TemperoryModel,id=otp_obj.user.id)
            except Exception as e:
                print(e)
            user_phone = temp_obj.user.phone
            print(user_phone, 'hello')
            user = get_object_or_404(User,phone = user_phone)
            print(user)
            user.is_active = True

            user.save()
            user_ad = temp_obj.address
            user_ct = temp_obj.city
            user_st = temp_obj.state
            user_zp = temp_obj.zipcode
            user_cn = temp_obj.country
            user_lt = temp_obj.latitude
            user_ln = temp_obj.longitude

            # 2. Main Table
            register = User_Registration.objects.get_or_create(user = user, address = user_ad, city= user_ct, state = user_st, zipcode = user_zp, country = user_cn, latitude = user_lt, longitude = user_ln)
            # register = User_Registration(user = user, address = user_ad, city= user_ct, state = user_st, zipcode = user_zp, country = user_cn, latitude = user_lt, longitude = user_ln)
            # temp_obj.delete()
            return render(request,'user/login.html')
        else:
            return render(request,'user/otp.html',{'msg':'Wrong OTP! Please enter correct OTP'})
    else:
        if request.user.is_authenticated:
            return render(request,'user/otp.html',{'msg':'Please verify your otp'})
        return render(request,'user/otp.html',{'msg':'Please verify your otp'})

def logoutnow(request):
    if request.method == 'POST':
        logout(request)
        return render(request, 'user/login.html')
    else:
        if request.user.is_authenticated:
            return redirect('/home/')
        return render(request, 'user/index.html')

def resend_otp(request):
    if request.method == 'GET':
        phone = request.session['mobile']
        otp_gen = str(random.randint(1000,9999))
        try:
            otp_obj = get_object_or_404(User_OTP, phone=phone)
        except Exception as e:
            print(e)
        otp_obj.otp_num = otp_gen
        otp_obj.save()
        send_otp(phone, otp_gen)
        return render(request,'user/resend_otp.html',{'msg':'Sent Successfully'})
    elif request.method == 'POST':
        otp_verify(request)
        if request.user.is_authenticated:
            return render(request,'user/login.html',{'msg':'Successfully'})
        else:
            return render(request,'user/otp.html',{'msg':'Wrong OTP'})

#Views for Vendor

def vendorregister(request):
    request.session['type'] = 'vendor'
    if request.method=='POST':
        email = request.POST.get('email','')
        phone = request.POST.get('phone','')
        password = request.POST.get('password','')
        confirm_password = request.POST.get('confirm_password','')
        first_name = request.POST.get('first_name','')
        last_name = request.POST.get('last_name','')
        address = request.POST.get('address','')
        city = request.POST.get('city','')
        state = request.POST.get('state','')
        zipcode = request.POST.get('zipcode','')
        country = request.POST.get('country','')
        latitude = request.POST.get('latitude',0.0)
        longitude = request.POST.get('longitude',0.0)
        referralCode = request.POST.get('referralCode','')
        user_exs = User.objects.filter(phone = phone, is_active = True).exists()
        if user_exs:
            print('helllo user')
            print(user_exs)
            return render(request,'vendor/index.html',{'msg':'Email or Phone number already taken'})
        user_exs = User.objects.filter(email = email, phone = phone, is_active = True).exists()
        print(user_exs)
        if user_exs:
            print('helllo user')
            print(user_exs)
            return render(request,'vendor/index.html',{'msg':'Email or Phone number already taken'})
        if password == confirm_password:
            try:
                print('48')
                user = User.objects.create_user(email = email, phone = phone, password= password, first_name = first_name, last_name = last_name, is_active = False)
                print(user)
                print('50')
                x = Vendor_TemperoryModel.objects.create(vuser = user, address= address, city = city, state = state, zipcode = zipcode, country = country, latitude = latitude, longitude = longitude)
                print('jitendra')
                x.save()
                print('meena')
                otp_gen= str(random.randint(1000,9999))
                otp_obj = Vendor_OTP(user = x, phone = phone, otp_num = otp_gen)
                otp_obj.save()
                if otp_obj is not None:
                    request.session['mobile'] = phone
                    send_otp(phone, otp_gen)
                    return redirect('/vendorotp/')
            except Exception as e:
                print(e)
                print('65')
                print(phone)
                try:
                    user_obj = get_object_or_404(User, phone = phone)
                    print('phone verified')
                except Exception as e:
                    print(e)
                    user_obj = get_object_or_404(User, email = email)
                    print('hello user')
                print('68')
                user_obj.delete()
                user = User.objects.create_user(email = email, phone = phone, password = password, first_name = first_name, last_name = last_name, is_active = False)
                print(user)
                x = Vendor_TemperoryModel.objects.create(vuser = user, address= address, city = city, state = state, zipcode = zipcode, country = country, latitude = latitude, longitude = longitude)
                print('jitendra')
                x.save()
                print('meena')
                otp_gen = str(random.randint(1000,9999))
                otp_obj = Vendor_OTP(vuser = x, phone = phone, otp_num = otp_gen)
                otp_obj.save()
                if otp_obj is not None:
                    request.session['mobile'] = phone
                    send_otp(phone, otp_gen)
                    return redirect('/vendorotp/')
                # return render(request,'user/index.html',{'msg':'Re-Enter your details'})
        else:
            return render(request,'vendor/index.html',{'error':'password not matched'})
    else:
        if request.user.is_authenticated:
            return render(request,'home.html')
        return render(request,'vendor/index.html')

def edit_vendorProfile(request):
    # form = VendorServiceDetailForm()
    if request.method == 'GET':
        if request.user.is_authenticated:
            print(request.user)
            user_profile = Vendor_Registration.objects.filter(vuser = request.user)
            user_obj = Vendor_Registration.objects.get(vuser =  request.user)
            service_obj = Service.objects.all()
            service_class_obj = ServiceClass.objects.all()[:3]
            selected_service = VendorService.objects.filter(vuser = user_obj)
            return render(request, 'vendor/edit_profile.html', {'user_data' : user_profile, 'service_obj' : service_obj, 'service_class_obj' : service_class_obj, 'selected_service': selected_service})
        else:
            return render(request, 'vendor/login.html')
    elif request.method == 'POST':
        img = request.FILES.get('profile_change')
        print(img)
        if img!= None:
            print("hii")
            profile_pic = request.FILES['profile_change']
            user_obj = get_object_or_404(Vendor_Registration, vuser = request.user)
            user_obj.profile_pic = profile_pic
            user_obj.save()
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        phone = request.POST['phone']
        user_obj = get_object_or_404(User, email = request.user)
        user_obj.first_name = first_name
        print(user_obj.first_name)
        user_obj.last_name = last_name
        user_obj.phone = phone
        user_obj.save()
        address = request.POST['address']
        user_obj = get_object_or_404(Vendor_Registration, vuser = request.user)
        user_obj.address = address
        user_obj.save()
        print(request.FILES)
        return redirect('/edit_vendorprofile')

@login_required(login_url='/userlogin')
def user_phone_verify(request):
    print(request.user)
    if request.method == 'POST':
        print(request.user)
        phone = request.POST.get('phone')
        print(phone)
        user_temp = User_TemperoryModel.objects.get(user = request.user)
        if User.objects.filter(phone = phone).exists():
            return render(request, 'user/phone_otp.html', {'msg':'Phone Number Already exists'})
        else:
            main_user = get_object_or_404(User, email = request.user)
            main_user.phone = phone
            main_user.save()
            otp_gen = str(random.randint(1000,9999))
            otp_obj = User_OTP(user = user_temp, phone = phone, otp_num = otp_gen)
            otp_obj.save()
            if otp_obj is not None:
                request.session['mobile'] = phone
                send_otp(phone, otp_gen)
                return redirect('/otp/')
            return render(request, 'user/phone_otp.html')
    return render(request, 'user/phone_otp.html')

def vendorloginnow(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try :
            echeck = get_object_or_404(User_Registration, vuser__email = email)
            print(echeck)
            print('hanuman')
            return render(request,'vendor/login.html', {'msg' : 'Already Registered for User'})
        except Exception as e:
            print('ram')
            print(e)
        user = authenticate(request, email = email, password = password)
        print(user)
        if user is not None:
            login(request, user)
            token, created = Token.objects.get_or_create(user=user)
            return redirect('/core/home/')
        else:
            return redirect('vendorlogin')
    else:
        if request.user.is_authenticated:
            return render(request, 'home.html')
        return render(request,'vendor/login.html')

# def home(request):
#     if request.user.is_authenticated:
#         return render(request, 'home.html')
#     else:
#         return render(request, 'user/login.html')

def vendorotp_verify(request):
    if request.method == 'POST':
        phone = request.session['mobile']
        user_otp = request.POST.get('otp')
        try:
            otp_obj = get_object_or_404(Vendor_OTP, phone=phone)
        except Exception as e:
            print(e)
            return render(request,'vendor/otp.html',{'msg':'Incorrect OTP'})
        db_otp = otp_obj.otp_num
        if db_otp == user_otp:
            print(otp_obj.vuser.id)
            
            #Fetching data from temperory table and then putting it into the Registration table
            # 1.Temp Table

            temp_obj = get_object_or_404(Vendor_TemperoryModel,id=otp_obj.vuser.id)
            user_phone = temp_obj.vuser.phone
            user = get_object_or_404(User,phone = user_phone)
            user.is_active = True

            user.save()
            user_ad = temp_obj.address
            user_ct = temp_obj.city
            user_st = temp_obj.state
            user_zp = temp_obj.zipcode
            user_cn = temp_obj.country
            user_lt = temp_obj.latitude
            user_ln = temp_obj.longitude

            # 2. Main Table
            register = Vendor_Registration(vuser = user, address = user_ad, city= user_ct, state = user_st, zipcode = user_zp, country = user_cn, latitude = user_lt, longitude = user_ln)
            register.save()
            # temp_obj.delete()
            return render(request,'vendor/login.html')
        else:
            return render(request,'vendor/otp.html',{'msg':'Wrong OTP! Please enter correct OTP'})
    else:
        if request.user.is_authenticated:
            return redirect('/home/')
        return render(request,'vendor/otp.html',{'msg':'Please verify your otp'})

def vendorlogoutnow(request):
    if request.method == 'POST':
        logout(request)
        return render(request, 'vendor/login.html')
    else:
        if request.user.is_authenticated:
            return redirect('/home/')
        return render(request, 'vendor/index.html')

def vendorresend_otp(request):
    if request.method == 'GET':
        phone = request.session['mobile']
        otp_gen = str(random.randint(1000,9999))
        try:
            otp_obj = get_object_or_404(Vendor_OTP, phone=phone)
        except Exception as e:
            print(e)
        otp_obj.otp_num = otp_gen
        otp_obj.save()
        send_otp(phone, otp_gen)
        return render(request,'vendor/resend_otp.html',{'msg':'Sent Successfully'})
    elif request.method == 'POST':
        otp_verify(request)
        if request.user.is_authenticated:
            return render(request,'vendor/login.html',{'msg':'Successfully'})
        else:
            return render(request,'vendor/otp.html',{'msg':'Wrong OTP'})

#  ADMIN_Login

