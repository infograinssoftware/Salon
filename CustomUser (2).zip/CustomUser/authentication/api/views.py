from rest_framework import status
from authentication.models import User_Registration, User_OTP, User_TemperoryModel, Vendor_Registration, Vendor_OTP, Vendor_TemperoryModel
from users.models import User 
from .serializers import User_RegistrationSerializer, User_Loginserializer, User_OTPSerailizer, User_TemperoryModelSerializer, User_ResedOTPSerailizer, Vendor_RegistrationSerializer, Vendor_TemperoryModelSerializer, Vendor_Loginserializer, Vendor_OTPSerailizer, Vendor_ResedOTPSerailizer, Edit_User_Profile_Serializer
from django.contrib.auth import authenticate, login
from rest_framework.generics import CreateAPIView, ListCreateAPIView, ListAPIView
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.shortcuts import get_object_or_404
from django.contrib.auth.tokens import default_token_generator
import random


class User_Registerapi(ListCreateAPIView):
    queryset = User_Registration.objects.all()
    serializer_class = User_RegistrationSerializer

class Edit_User_Profileapi(ListCreateAPIView):
    queryset = User_Registration.objects.all()
    serializer_class = Edit_User_Profile_Serializer
    def get(self, request, myid, formate = None):
        user_obj = User_Registration.objects.get(user = myid)
        serializer = Edit_User_Profile_Serializer(user_obj)
        return Response({'data': serializer.data})

# **********************************************
    # Complete this method after Linked by Device **********************************************

    # def post(self, request, id):
    #     user_obj = User_Registration.objects.get(user = myid)
    #     user_obj.address = address
    #     if img!= None:
    #         print("hii")
    #         profile_pic = request.FILES['profile_change']
    #         user_obj = get_object_or_404(User_Registration, user = request.user)
    #         user_obj.profile_pic = profile_pic
    #         user_obj.save()
    #     first_name = request.data.get('first_name')
    #     last_name = request.data.get('last_name')
    #     user_obj = get_object_or_404(User, email = request.user)
    #     user_obj.first_name = first_name
    #     print(user_obj.first_name)
    #     user_obj.last_name = last_name
    #     user_obj.phone = phone
    #     user_obj.save()
    #     address = request.data.get('address')
    #     state = request.data.get('state')
    #     city = request.data.get('city')
    #     zipcode = request.data.get('zipcode')
    #     latitude = request.data.get('latitude')
    #     longitude = request.data.get('longitude')
    #     user_obj = get_object_or_404(User_Registration, user = request.user)
    #     user_obj.address = address
    #     user_obj.state = state
    #     user_obj.city = city
    #     user_obj.zipcode = zipcode
    #     user_obj.latitude = latitude
    #     user_obj.longitude = longitude
    #     user_obj.save()
# **********************************************

class User_Temporaryapi(ListCreateAPIView):
    queryset = User_TemperoryModel.objects.all()
    serializer_class = User_TemperoryModelSerializer

class User_Loginapi(ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = User_Loginserializer

    def post(self, request):
        email = request.data.get("email")
        password = request.data.get("password")
        try :
            echeck = get_object_or_404(Vendor_Registration, vuser__email = email)
            print(echeck)
            print('Jai ambey mata')
            return Response({'msg' : 'Already Registered for Vendor'},status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print(e)
        user = authenticate(email=email, password=password)
        if user:
            login(request, user)
            token, created = Token.objects.get_or_create(user=user)
            return Response({'msg':f'Login successful + {token}'},status=status.HTTP_200_OK)
        else:
            return Response({"error": "Wrong Credentials"}, status=status.HTTP_400_BAD_REQUEST)


class User_OTPAPI(ListCreateAPIView):
    queryset = User_OTP.objects.all()
    serializer_class = User_OTPSerailizer
    def post(self,request):
        phone = request.data.get('phone')
        user_otp = request.data.get('otp_num')
        try:
            otp_obj = get_object_or_404(User_OTP, phone=phone)
            print('hello')
        except Exception as e:
            return Response({"msg": 'Sorry please reverify'}, status=status.HTTP_400_BAD_REQUEST)

        db_otp = otp_obj.otp_num
        if db_otp == user_otp:
            print(otp_obj.user.id)
            
            #Fetching data from temperory table and then putting it into the Registration table
            # 1.Temp Table

            temp_obj = get_object_or_404(User_TemperoryModel,id=otp_obj.user.id)
            user_phone = temp_obj.user.phone
            user = get_object_or_404(User,phone = user_phone)
            user.is_active = True

            user.save()
            user_ct = temp_obj.city
            user_st = temp_obj.state
            user_zp = temp_obj.zipcode
            user_cn = temp_obj.country

            # 2. Main Table
            register = User_Registration(user = user, city= user_ct, state = user_st, zipcode = user_zp, country = user_cn)
            register.save()
            return Response({"msg": 'Yes this is the correct OTP'}, status=status.HTTP_400_BAD_REQUEST)
        return Response({"msg": 'Sorry please reverify'}, status=status.HTTP_400_BAD_REQUEST)
    
class User_ResendOTPAPI(ListCreateAPIView):
    queryset = User_OTP.objects.all()
    serializer_class = User_ResedOTPSerailizer
    
    def post(self,request):
        phone = request.data.get('phone')
        user_otp = request.data.get('otp_num')
        try:
            otp_obj = get_object_or_404(User_OTP, phone=phone)
            print('hello')
        except Exception as e:
            return Response({"msg": 'Invalid Phone Number'}, status=status.HTTP_400_BAD_REQUEST)
        db_otp = otp_obj.otp_num
        if db_otp == user_otp:
            print(otp_obj.user.id)
            
            #Fetching data from temperory table and then putting it into the Registration table
            # 1.Temp Table

            temp_obj = get_object_or_404(User_TemperoryModel,id=otp_obj.user.id)
            user_phone = temp_obj.user.phone
            user = get_object_or_404(User,phone = user_phone)
            user.is_active = True

            user.save()
            user_ct = temp_obj.city
            user_st = temp_obj.state
            user_zp = temp_obj.zipcode
            user_cn = temp_obj.country

            # 2. Main Table
            register = User_Registration(user = user, city= user_ct, state = user_st, zipcode = user_zp, country = user_cn)
            register.save()
            return Response({"msg": 'Yes this is the correct OTP'}, status=status.HTTP_400_BAD_REQUEST)
        return Response({"msg": 'Sorry please reverify'}, status=status.HTTP_400_BAD_REQUEST)

        # def get(self,request):
    #     pass
        # phone = request.data.get('phone')
        # # otp_gen = str(random.randint(1000,9999))
        # try:
        #     otp_obj = get_object_or_404(OTP, phone=phone)
        #     print('hello')
        # except Exception as e:
        #     print(e)
        #     return Response({"msg": 'Invalid Phone Number'}, status=status.HTTP_400_BAD_REQUEST)
        # # otp_obj.otp_num = otp_gen
        # # otp_obj.save()
        # # send_otp(phone, otp_gen)
        # return Response({"msg": 'Enter phone and otp '}, status=status.HTTP_400_BAD_REQUEST)
    


# API for vendor

class Vendor_Registerapi(ListCreateAPIView):
    queryset = Vendor_Registration.objects.all()
    serializer_class = Vendor_RegistrationSerializer

class Vendor_Temporaryapi(ListCreateAPIView):
    queryset = Vendor_TemperoryModel.objects.all()
    serializer_class = Vendor_TemperoryModelSerializer

class Vendor_Loginapi(ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = Vendor_Loginserializer

    def post(self, request):
        email = request.data.get("email")
        password = request.data.get("password")
        try :
            echeck = get_object_or_404(User_Registration, user__email = email)
            print(echeck)
            print('Jai ambey mata')
            return Response({'msg' : 'Already Registered for Vendor'},status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print(e)
        user = authenticate(email=email, password=password)
        if user:
            login(request, user)
            token, created = Token.objects.get_or_create(user=user)
            return Response({'msg':f'Login successful + {token}'},status=status.HTTP_200_OK)
        else:
            return Response({"error": "Wrong Credentials"}, status=status.HTTP_400_BAD_REQUEST)

class Vendor_OTPAPI(ListCreateAPIView):
    queryset = Vendor_OTP.objects.all()
    serializer_class = Vendor_OTPSerailizer
    def post(self,request):
        phone = request.data.get('phone')
        user_otp = request.data.get('otp_num')
        try:
            otp_obj = get_object_or_404(Vendor_OTP, phone=phone)
            print('hello')
        except Exception as e:
            return Response({"msg": 'Sorry please reverify'}, status=status.HTTP_400_BAD_REQUEST)

        db_otp = otp_obj.otp_num
        if db_otp == user_otp:
            print(otp_obj.user.id)
            
            #Fetching data from temperory table and then putting it into the Registration table
            # 1.Temp Table

            temp_obj = get_object_or_404(Vendor_TemperoryModel,id=otp_obj.user.id)
            user_phone = temp_obj.user.phone
            user = get_object_or_404(User,phone = user_phone)
            user.is_active = True

            user.save()
            user_ct = temp_obj.city
            user_st = temp_obj.state
            user_zp = temp_obj.zipcode
            user_cn = temp_obj.country

            # 2. Main Table
            register = Vendor_Registration(user = user, city= user_ct, state = user_st, zipcode = user_zp, country = user_cn)
            register.save()
            return Response({"msg": 'Yes this is the correct OTP'}, status=status.HTTP_400_BAD_REQUEST)
        return Response({"msg": 'Sorry please reverify'}, status=status.HTTP_400_BAD_REQUEST)
    
class Vendor_ResendOTPAPI(ListCreateAPIView):
    queryset = Vendor_OTP.objects.all()
    serializer_class = Vendor_ResedOTPSerailizer
    
    def post(self,request):
        phone = request.data.get('phone')
        user_otp = request.data.get('otp_num')
        try:
            otp_obj = get_object_or_404(Vendor_OTP, phone=phone)
            print('hello')
        except Exception as e:
            return Response({"msg": 'Invalid Phone Number'}, status=status.HTTP_400_BAD_REQUEST)
        db_otp = otp_obj.otp_num
        if db_otp == user_otp:
            print(otp_obj.user.id)
            
            #Fetching data from temperory table and then putting it into the Registration table
            # 1.Temp Table

            temp_obj = get_object_or_404(Vendor_TemperoryModel,id=otp_obj.user.id)
            user_phone = temp_obj.user.phone
            user = get_object_or_404(User,phone = user_phone)
            user.is_active = True

            user.save()
            user_ct = temp_obj.city
            user_st = temp_obj.state
            user_zp = temp_obj.zipcode
            user_cn = temp_obj.country

            # 2. Main Table
            register = Vendor_Registration(user = user, city= user_ct, state = user_st, zipcode = user_zp, country = user_cn)
            register.save()
            return Response({"msg": 'Yes this is the correct OTP'}, status=status.HTTP_400_BAD_REQUEST)
        return Response({"msg": 'Sorry please reverify'}, status=status.HTTP_400_BAD_REQUEST)


























# from rest_framework.decorators import api_view
# from rest_framework.permissions import IsAuthenticated, IsAdminUser, IsAuthenticatedOrReadOnly, AllowAny
# from rest_framework.authentication import TokenAuthentication
# from django.views.decorators.csrf import csrf_exempt
# from rest_framework.response import Response
# class ClassList(ListAPIView):
#     queryset= ClassAPI.objects.all()
    
#     serializer_class= Classserializer






# if otp_obj.otp_num == otp:
#                 return Response({"error": "Right Credentials"}, status=status.HTTP_200_OK)
#             else:
#                 return Response({"error": "Wrong Credentials"}, status=status.HTTP_400_BAD_REQUEST)



# @csrf_exempt
# @api_view(['GET','POST'])
# def homeapi(request): 
#     if request.method=='POST':
#         Password = request.data.get('Password')
#         print(Password)
#         serializer = Classserializer(data=request.data,many=True)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#     data = ClassAPI.objects.all()
#     serializer = Classserializer(data, many=True)
#     return Response(serializer.data)


    # queryset= ClassAPI.objects.all()
    # serializer_class= Classserializer


#Confused about last OTP conflict : 
    
        # print(type(otp_num))
        # otp_obj = get_object_or_404(OTP,otp_num = otp_num)
        # print(otp_obj,otp_obj.user.id)



        # print(request.user)
        # otp_num = request.data.get('otp_num')
        # print(otp_num)
        # print(type(otp_num))
        # otp_obj = get_object_or_404(OTP,otp_num = otp_num)
        # print(otp_obj,otp_obj.user.id)



        # otp_obj = get_object_or_404(OTP,user = id)
        # print(otp_obj.id,otp_obj.otp_num)
        # reg_obj = get_object_or_404(Registration,id = id)
        # print(type(reg_obj.id))
        # print(reg_obj,reg_obj.id)

        # userid = 0
        # id = Registration.objects.values('id')
        # userotp = request.data.get('otp_num')
        # email_obj = OTP.objects.values('user','otp_num')
        # print('hello')
        # for i in email_obj:
        #     for a in id:
        #         for j in a:
        #             for x in i:
        #                 idu = a[j]
        #                 print(idu)
        #                 if int(i[x])==int(idu):
        #                     userid = i[x]
        #                     print(userid,idu)
        #                     print('Bhaiya Raaam')
        #                     obj = OTP.objects.get(user = userid)
        #                     print(obj)
        #                     print(type(obj))
        #                     db_otp = obj.otp_num