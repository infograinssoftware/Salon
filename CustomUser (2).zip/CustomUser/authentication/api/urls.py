from django.urls import path, include
from authentication.api.views import User_Registerapi, User_Loginapi, User_OTPAPI, User_Temporaryapi, User_ResendOTPAPI, Vendor_Registerapi, Vendor_Loginapi, Vendor_OTPAPI, Vendor_Temporaryapi, Vendor_ResendOTPAPI, Edit_User_Profileapi
urlpatterns = [
    path('apiuserregister/',User_Temporaryapi.as_view(),name='apiuserregister'),
    path('apiuserlogin/',User_Loginapi.as_view(),name='apiuserlogin'),
    path('apiuserapi_otp/',User_OTPAPI.as_view(),name='apiuserapi_otp'),
    path('apiuserapi_resend_otp/',User_ResendOTPAPI.as_view(),name='apiuserapi_resend_otp'),
    path('apiedit_userprofile/<int:myid>',Edit_User_Profileapi.as_view(), name = 'apiedit_userprofile'),

    #vendor end points

    path('apivendorregister/',Vendor_Temporaryapi.as_view(),name='apivendorregister'),
    path('apivendorlogin/',Vendor_Loginapi.as_view(),name='apivendorlogin'),
    path('apivendorapi_otp/',Vendor_OTPAPI.as_view(),name='apivendorapi_otp'),
    path('apivendorapi_resend_otp/',Vendor_ResendOTPAPI.as_view(),name='apivendorapi_resend_otp'),

    path('password_reset/', include('django_rest_passwordreset.urls', namespace='password_reset')),
]