# from django import forms
# from superadmin.models import ServiceClass

# class VendorServiceForm(forms.ModelForm):
#     class Meta:
#         model = ServiceClass
#         fields = ['service_type']