from django.urls import path
from .views import ServiceAPI, ServiceClassAPI
urlpatterns=[
    path('super/service_api',ServiceAPI.as_view(), name = 'vendorservice_api'),
    path('super/serviceclass_api',ServiceClassAPI.as_view(), name = 'serviceclass_api'),
]