from rest_framework import serializers
from superadmin.models import Service, ServiceClass
class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = '__all__'

class ServiceClassSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceClass
        fields = '__all__'    
        