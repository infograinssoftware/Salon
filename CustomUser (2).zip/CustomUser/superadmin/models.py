from django.db import models
from multiselectfield import MultiSelectField
# Register your models here.

class Service(models.Model):
    service = models.CharField(max_length = 30, default= 'Hairstyle')
    def __str__(self):
        return str(self.service)

class ServiceClass(models.Model):
    service_type = models.CharField(max_length=100)
    def __str__(self):
        return str(self.service_type)



