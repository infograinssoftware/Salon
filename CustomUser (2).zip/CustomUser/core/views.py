from django.shortcuts import render, get_object_or_404, redirect
from authentication.models import User_Registration, Vendor_Registration
from users.models import User
from django.db.models import Q
from superadmin.models import ServiceClass, Service
from .models import VendorService, BookingInvoice, BookingRequest, BookingResponse, Confirm_Booking
from django.views.generic import View
from multiselectfield import MultiSelectField
import stripe
from django.conf import settings
from django.http import JsonResponse
from django.views import View
from django.views.generic import TemplateView
from django.views.generic.edit import CreateView

stripe.api_key = settings.STRIPE_SECRET_KEY

class CreateCheckoutSessionView(View):
    def post(self, request, *args, **kwargs):
        request.session['payment_status'] = 'Done'
        product_id = self.kwargs["pk"]
        request.session['prd_id'] = product_id
        product = BookingResponse.objects.get(id=product_id)
        request.session['bk_id'] = product.user_booking_request.id
        YOUR_DOMAIN = "http://127.0.0.1:8000"
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[
                {
                    'price_data': {
                        'currency': 'usd',
                        'unit_amount': int(product.price) *100,
                        'product_data': {
                            'name': product.user_booking_request
                        },
                    },
                    'quantity': 1,
                },
            ],
            metadata={
                "product_id": product.id
            },
            mode='payment',
            success_url=YOUR_DOMAIN + '/success/',
            cancel_url=YOUR_DOMAIN + '/cancel/',
        )
        return JsonResponse({
            'id': checkout_session.id
        })

class SuccessView(TemplateView):
    template_name = "success.html"
    def get(self, request, *args, **kwargs):
        status = request.session.get('payment_status')
        id = request.session.get('bk_id')
        print(id)
        context = {'Status': 'Bhag re'}
        if status:
            booking_status = BookingRequest.objects.get(id = id)
            booking_status.status = True
            booking_status.save()
            context = {'Status': 'Payment Done'}
            id = request.session.get('prd_id')
            booking_res_obj = BookingResponse.objects.get(id = id)
            confirm_bookings = Confirm_Booking.objects.create(confirm_booking_detail = booking_res_obj, disp_status = 'Booked')
            confirm_bookings.save()
            return redirect(f'http://127.0.0.1:8000/product_landing/{id}')
        return render(request, template_name = self.template_name, context = context)

class CancelView(TemplateView):
    template_name = "cancel.html"

class ProductLandingPageView(TemplateView):
    template_name = "landing.html"

    def get_context_data(self, **kwargs):
        id = kwargs.get('id')
        print('76',id)
        product = BookingResponse.objects.get(id = id)
        context = super(ProductLandingPageView, self).get_context_data(**kwargs)
        context.update({
            "product": product,
            "STRIPE_PUBLIC_KEY": settings.STRIPE_PUBLIC_KEY
        })
        return context

# Create your views here.
def home(request):
    if request.user.is_authenticated:
        return render(request, 'home.html')
    else:
        return render(request, 'user/login.html')
    return render(request, 'sociallogin.html',)

def serviceplace(request):
    service_type = request.GET.get('search')
    print(service_type)
    filtered_vendor = ''
    if service_type is not None:
        filtered_vendor = VendorService.objects.filter(vendor_service_class__service_type = service_type)
        print(filtered_vendor)
    return render(request, 'serviceplace.html', {'data' : filtered_vendor })



def login_status(request):
    if request.method == 'POST':
        print(request.POST.getlist('vendor_service_class[]'))
        service_obj = ServiceClass.objects.create(service_type = request.POST.getlist('vendor_service_class[]'))
        print(service_obj)
        v = Vendor_Registration.objects.get(vuser = request.user)
        print(v)
        print(type(request.POST['vendor_service']))
        ss = Service.objects.get(id = int(request.POST['vendor_service']))
        print(ss)
        vv = VendorService(vuser_id = v.id, vendor_service_id =  int(request.POST['vendor_service']))
        vv.save()
        vv.vendor_service_class.set(service_obj.service_type)
        return redirect('/core/last/')
    return render(request, 'vendorservice_form.html')

def VendorSearch(request):
    service_obj = Service.objects.all()
    service_class_obj = ServiceClass.objects.all().order_by('id')[:3]
    print(service_class_obj)
    booking = BookingInvoice.objects.filter(user__user__email = request.user)
    
    return render(request,'vendorfilter.html', {'service_obj': service_obj, 'service_class_obj':service_class_obj, 'booking': booking})

def selectservice(request):
    if request.method == 'POST':
        date = request.POST.get('date')
        desc = request.POST.get('desc')
        booking_service = request.POST.get('booking_service')
        booking_service_class = request.POST.get('booking_service_class')
        print(date)
        v = User_Registration.objects.get(user = request.user)
        booking = BookingInvoice.objects.create(user = v,booking_service =  booking_service, booking_service_class = booking_service_class, booking_date = date, booking_desc = desc)
        booking.save()
        vendor_list = Vendor_Registration.objects.all()
        booking_user_obj = BookingInvoice.objects.filter(user = v)
        for i in booking_user_obj:
            print(i,"hsddffhfihfifio")
        print(len(vendor_list))
        for i in vendor_list:
            vendor_list = Vendor_Registration.objects.get(vuser__email = i.vuser)
            print(vendor_list,'dfsdfsafsdf')
            print(request.user)
            booking_obj = BookingRequest.objects.create(user_booking_invoice = booking, vendor = vendor_list, status = False)
            booking_obj.save()
        return redirect('vendorsearch')
    return redirect('vendorsearch')

def final_invoice(request):
    booking = BookingInvoice.objects.filter(user__user__email = request.user).order_by('-booking_date')[:1]
    return render(request, 'Final_Invoice.html', {'booking': booking})

def request_confirm(request):
    vendor = Vendor_Registration.objects.get(vuser__email = request.user)
    booking_obj = BookingRequest.objects.filter(vendor = vendor)
    return render(request, 'request_confirm.html', {'booking_obj' : booking_obj})

def vendor_response(request, user_id):
    if request.method == 'POST':
        price = request.POST.get('price')
        booking_request_obj = BookingRequest.objects.get(id = user_id)
        booking_response_obj = BookingResponse.objects.create(user_booking_request = booking_request_obj, price = price)
    return render(request, 'request_confirm.html', {'bro': 'Sent Your Bid'})

def vendor_reject_response(request, user_id):
    booking_obj = BookingRequest.objects.get(id = user_id).delete()
    return redirect('/core/request_confirm/')

def response_list(request):
    print(request.user.id)
    response_lists = BookingResponse.objects.filter(user_booking_request__user_booking_invoice__user__user__email = request.user)
    return render(request, 'response_list.html', {'response_list' : response_lists})

def my_bookings(request):
    mybookings = Confirm_Booking.objects.filter(confirm_booking_detail__user_booking_request__user_booking_invoice__user__user__email = request.user)
    return render(request, 'my_booking.html', {'mybookings': mybookings})

def vendor_bookings(request):
    mybookings = Confirm_Booking.objects.filter(confirm_booking_detail__user_booking_request__vendor__vuser__email = request.user)
    print(my_bookings)
    return render(request, 'vendor_bookings.html', {'mybookings': mybookings})

def waiting(request):
    return render(request, 'waiting.html')





# from superadmin.forms import VendorServiceForm
# from .forms import VendorServiceDetailForm
#Stripe imports

#For Request confirm view
  # booking_lists = {}
    # for i in booking_obj:
    #     print(i.user_booking_invoice.user)
    # # print(booking_obj.user_booking_invoice.user)
    #     user_booking_obj = BookingInvoice.objects.filter(user__user__email = i.user_booking_invoice.user)
    #     booking_lists.update({i.user_booking_invoice:user_booking_obj})
    # # print(user_booking_obj)
    # # print(booking_lists)
    # # for x, y in booking_lists:
    # #     print(x.user_booking_invoice, 'sdfasfjhsahfjsafysdfgsuidf')


    
# def filterdata(request):
#     data = User_Registration.objects.all()
#     return render(request, 'filter.html', {'data' : data})
    
# def socially(request):
#     re

 # print(search)
    # search = MultiSelectField(search)
    # print(type(search))
    # vv = ServiceClass.objects.all()
    # x = []
    # for i in vv:
    #     print(i.service_class, type(i.service_class))
    #     x.append(str(i.service_class))
    # print(x)
    # vv = ServiceClass.objects.all()
    # for i in vv:
    #     print(i.service_class)
# def checktest(request):
#     form = ServiceForm()
#     return render(request,'vendorfilter.html',{'form': form})

 # search = request.GET.get('search')
    # if search == 'S' or search == 'E':
    #     v = VendorService.objects.filter(Q(vendor_service_class__service_class__icontains = 'S')|Q(vendor_service_class__service_class__icontains = 'E')).exclude(vuser__vuser__is_superuser = True)
    # else:
    #     v = VendorService.objects.filter(Q(vendor_service_class__service_class__icontains = 'V'))


    
# def login_status(request):
#     form = VendorServiceForm()
#     print(form)
#     if request.method == 'POST':
#         form = VendorServiceForm(request.POST)
#         print(form)
#         if form.is_valid():
#             print('hello')
#             form.save()
#     return redirect('edit_vendorprofile')
    

# class VendorSearch(View):
#     template_name = 'vendorfilter.html'
#     def get(self, request, *args, **kwargs):
#         print(args)

#         return render(request, template_name = self.template_name)
    
    # user = User.objects.all().exclude(Q(email = request.user)|Q(is_superuser = True))
# def VendorSearchs(request):
#     return render(request,'vendorfilter.html')



    # model = VendorService
    # fields = '__all__'
    # template_name = 'vendorservice_form.html'
    # success_url = '/edit_vendorprofile'

    # form = VendorServiceDetailForm()
    

        # print('hh')
        # serviceform = VendorServiceDetailForm(request.POST)
        # print('dfd')

        # if serviceform.is_valid():
        #     print('hdfsd')
        #     serviceform.save()
        # v = Service.objects.get(id = request.POST.get('vendor_service'))
        # print(v, type(v))
        # print(request.POST["vendor_service_class"])
        # p = ServiceClass.objects.get(service_type = request.POST.get('vendor_service_class'))
        # print(p)
        # serviceform = VendorServiceDetailForm(request.POST, instance= p)
        # if serviceform.is_valid():
        #     print('hh')
        #     item_form_obj = serviceform.save(commit=False)
        #     item_form_obj.vendor_service = v
        #     item_form_obj.save()

        # form = VendorServiceDetailForm(request.POST)
        # print(form.errors)
        # print('hello')
        # try:
        #     if form.is_valid():
        #         print(form.errors)
        #         print('hello')
        #         form.save()
        #     else:
        #         print(form.errors)
        # except Exception as e:
        #     print(e)
        # service = request.POST.get('service')
        # service_class = request.POST.get('vendor_service_choices')
        # print(type(service), service)
        # print(type(service_class))
        # try:
        #     vendor_obj = get_object_or_404(Vendor_Registration, vuser__email = request.user)
        #     service = Service.objects.get(service =  service)
        #     service_class = ServiceClass.objects.create(id =  service_class)

        #     vendor_service = VendorService.objects.get_or_create(vuser = vendor_obj, vendor_service = service, vendor_service_class = service_class)
        # except Exception as e:
        #     print(e)
        # if type(vendor_service) == tuple:
        #     return redirect('edit_vendorprofile')
        # print(type(vendor_service))
        # vendor_service.save()