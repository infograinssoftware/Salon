from django import forms
# from superadmin.models import Service,ServiceClass
# from .models import VendorService

# class VendorServiceDetailForm(forms.ModelForm):
#     vendor_service_choices= [
#         ('Standard', 'Standard'),
#         ('Exotic', 'Exotic'),
#         ('VIP', 'VIP')
#     ]
#     # forms.CharField(widget = forms.HiddenInput(), required = False)
#     vendor_service = forms.ModelChoiceField(queryset= Service.objects.all())
#     vendor_service_class = forms.ModelMultipleChoiceField(queryset= ServiceClass.objects.all(), widget = forms.CheckboxSelectMultiple)
#     class Meta:
#         model = VendorService
#         fields = ['vuser','vendor_service', 'vendor_service_class']