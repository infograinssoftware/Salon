from django.contrib import admin
from .models import VendorService, BookingInvoice, BookingRequest, BookingResponse, Confirm_Booking

@admin.register(VendorService)
class VendorServiceAdmin(admin.ModelAdmin):
    list_display = ['vuser','vuser', 'vendor_service']

@admin.register(BookingInvoice)
class BookingInvoiceAdmin(admin.ModelAdmin):
    list_display = ['user','current_date','booking_service','booking_service_class','booking_date','booking_desc']
    
@admin.register(BookingRequest)
class BookingRequestAdmin(admin.ModelAdmin):
    list_display = ['id','user_booking_invoice','vendor','status']

admin.site.register(BookingResponse)
# class BookingResponseAdmin(admin.ModelAdmin):
#     list_display = ['id','user_booking_request','price']

@admin.register(Confirm_Booking)
class Confirm_BookingAdmin(admin.ModelAdmin):
    list_display = ['id','confirm_booking_detail','disp_status']









# @admin.register(VendorServiceProvide)
# class VendorServiceProvideAdmin(admin.ModelAdmin):
#     class Meta:
#         model = VendorServiceProvide
#         list_display = ['service', 'p']

# admin.site.register(VendorService)
# # class VendorServiceAdmin(admin.ModelAdmin):
# #     list_display = ['user', 'service_class']

# @admin.register(VendorServicePrice)
# class VendorServiceAdmin(admin.ModelAdmin):
        
#     list_display = ['service']