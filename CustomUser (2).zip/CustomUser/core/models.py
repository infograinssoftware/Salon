from django.db import models
from superadmin.models import Service, ServiceClass
from authentication.models import Vendor_Registration, User_Registration

class VendorService(models.Model):
    vuser = models.ForeignKey(Vendor_Registration, on_delete = models.CASCADE, db_column = 'vuser')
    vendor_service = models.ForeignKey(Service, on_delete = models.CASCADE, related_name = 'vendor_service')
    vendor_service_class = models.ManyToManyField(ServiceClass)
    def __str__(self):
        return str(self.vendor_service_class.all())

    
    # yet to try
class BookingInvoice(models.Model):
    user = models.ForeignKey(User_Registration, on_delete = models.CASCADE)
    current_date = models.DateTimeField(auto_now = True)
    booking_service = models.CharField(max_length = 50)
    booking_service_class = models.CharField(max_length = 50)
    booking_date = models.DateTimeField()
    booking_desc = models.TextField(max_length = 300)
    def __str__(self):
        return f'{self.user.user.first_name} {self.user.user.last_name} booked {self.booking_service} with {self.booking_service_class} at {self.booking_date}'

class BookingRequest(models.Model):
    user_booking_invoice = models.ForeignKey(BookingInvoice, on_delete = models.CASCADE)
    vendor = models.ForeignKey(Vendor_Registration, on_delete = models.CASCADE)
    status = models.BooleanField(default = False)
    def __str__(self):
        return f'{self.user_booking_invoice.user} Requested {self.vendor}'

class BookingResponse(models.Model):
    user_booking_request = models.ForeignKey(BookingRequest, on_delete = models.CASCADE)
    price = models.PositiveIntegerField()
    
    def __str__(self):
        return f'{self.user_booking_request.vendor.vuser.first_name.title()} bid price of {self.price}$ for {self.user_booking_request.user_booking_invoice.booking_service} to {self.user_booking_request.user_booking_invoice.user.user.first_name}'

    def get_display_price(self):
        return "{0:.2f}".format(self.price)

class Confirm_Booking(models.Model):
    Disp_Status = (
        ('Booked', 'Booked'),
        ('In a Way', 'On The Way'),
        ('Completed', 'Completed'),
    )
    confirm_booking_detail = models.ForeignKey(BookingResponse, on_delete = models.CASCADE)
    disp_status = models.CharField(max_length = 30, choices = Disp_Status)



































    # vendor_service_class = models.ManyToManyField(ServiceClass)


# class Post(models.Model):
#     name = models.CharField(max_length=200)
#     tags = ArrayField(models.CharField(max_length=200), blank=True)

#     def __str__(self):
#         return self.tags

# class ChessBoard(models.Model):
#     board = ArrayField(
#         ArrayField(
#             models.CharField(max_length=10, blank=True),
#             size=8,
#         ),
#         size=8,
#     )
#     def __str__(self):
#         return str(self.board)


































# from multiselectfield import MultiSelectField

# class VendorServiceProvide(models.Model):
#     service = models.CharField(max_length = 30) 
#     def __str__(self):
#         return f'{self.service}'
        
# class VendorService(models.Model):
#     services = [
#         ('S','Standard'),
#         ('E', 'Exotic'),
#         ('V','VIP')
#     ]
#     user = models.ForeignKey(Vendor_Registration, on_delete = models.CASCADE)
#     service = models.ManyToManyField('VendorServiceProvide',  related_name = 'services_of_vendor') 
#     service_class = MultiSelectField(choices = services, max_choices = 3,  default = 'S')
    
#     def __str__(self):
#         l = self.service.all()
#         l1 = ''
#         for i in l:
#             l1 = l1 + str(i.service) + ", "
#         return f'{self.user.vuser.first_name} provides {l1} with  {self.service_class}'
#     # l1 = ''
#     # def __str__(self):
#     #     global l1
        
#     #     l = self.service.all()
#     #     for i in l:
#     #         l1 = l1 + str(i.service) + ", "
#     #     l1 = l1
#     #     return str(self.user.vuser, self.l1)

# class VendorServicePrice(models.Model):
#     service = models.ForeignKey(VendorService, on_delete = models.CASCADE, related_name = 'vendor_service')
#     service_class = models.ForeignKey(VendorService, on_delete = models.CASCADE, related_name = 'vendor_service_class')
#     total_price = models.PositiveIntegerField() 
#     def __str__(self):
#         return f'{self.service.service} with {self.service_class.service_class} class {self.total_price}' 
    

    
